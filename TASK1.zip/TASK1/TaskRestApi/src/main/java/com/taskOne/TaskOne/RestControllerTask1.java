package com.taskOne.TaskOne;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class RestControllerTask1 {

    @Autowired
    ClRmSystem clRmSystem;

    //This means that the url will include the input and this input is linked to the string input argument.
    //Then I used the object clRMSystem to find the runner method and pass it the input argument.
    //This code is inspired by: https://www.youtube.com/watch?v=A04J3kHnofE
    @GetMapping("/output/{input}")
    public String getOutput(@PathVariable("input") String input){
        return clRmSystem.runner(input);
    }

}
