package com.taskOne.TaskOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClRmApplication {

        public static void main(String... args) {
            SpringApplication.run(ClRmApplication.class, args);
        }

}
