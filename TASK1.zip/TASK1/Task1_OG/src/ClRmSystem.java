import java.util.Scanner;


public class ClRmSystem {


    /**
     * This method checks that the input format is correct by testing that
     * there are only 4 arguments that are positive integers.
     * @param userInput Array of inputs from the user.
     * @return true if the format is correct, false if wrong.
     */
    private boolean inputFormatCheck(String [] userInput){
        if(userInput.length != 4){
            return false;
        }
        else{
            try{
                for (String individualArgs: userInput){
                    int castResult = Integer.parseInt(individualArgs);
                    if(castResult < 0){
                        return false;
                    }
                }
            }catch(NumberFormatException e){
                System.out.println("Fields need to be numeric!!");
                return false;
            }
        }
        return true;
    }

    /**
     * Checks that resources are not overused, by checking that their value
     * don't pass a certain value
     * @param userInput represents the values received from user.
     * @return first argument represents if there's any overused resource,
     * second argument represent the cpu, third arg represent the memory,
     * fourth argument represent the disk. False indicates no over usage
     * true indicates over usage.
     */
    private boolean[] resourcesUsageCheck(String[] userInput){
        //first argument helps avoiding unnecessary search.
        boolean[] issues = {false,false,false,false};
        for(int i = 0; i < userInput.length; i++){
            switch (i){
                case 1:
                    if(Integer.parseInt(userInput[i]) > 85){
                        issues[0] = true;
                        issues[1] = true;
                    }
                    break;
                case 2:
                    if(Integer.parseInt(userInput[i]) > 75){
                        issues[0] = true;
                        issues[2] = true;
                    }
                    break;
                case 3:
                    if(Integer.parseInt(userInput[i]) > 60){
                        issues[0] = true;
                        issues[3] = true;
                    }
                    break;
            }
        }
        return issues;

    }

    /**
     * Formatting the output to be in the required format.
     * @param issues this array is used to indicate which resource is overused.
     * @param serverID serverID is required to satisfy the output format
     * @return string the represents the output.
     */
    private String formattingOutput(boolean[] issues, String serverID){
        StringBuilder output = new StringBuilder();
        if(issues[0]){
            output.append("(Alert,").append(serverID);
            for(int i = 0; i < issues.length; i++){
                switch (i){
                    case 1:
                        if(issues[i] == true){
                            output.append(",CPU_UTILIZATION VIOLATED");
                        }
                        break;

                    case 2:
                        if(issues[i] == true){
                            output.append(",MEMORY_UTILIZATION VIOLATED");
                        }
                        break;

                    case 3:
                        if(issues[i] == true){
                            output.append(",DISK_UTILIZATION VIOLATED)");
                        }
                        else{
                            output.append(")");
                        }
                        break;
                }
            }

        }
        else{
            output.append("(No Alert,").append(serverID).append(")");
        }

       return output.toString();

    }

    /**
     * This method parses the command line input from the user.
     * @return usage values in the required format
     */
    private String[] parsingInput(){
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        String[] indElements = input.replace("(","").replace(")","").split(",");
        return  indElements;
    }

    /**
     * This method checks the format entered by the user, if it's correct
     * it uses the resourceUsageCheck method to check if there's any violations.
     * the result is then passed to the formattingOutput method to print,
     * the result in the required format.
     * @param userInput input of the user.
     * @return false if the structure of the input was incorrect, true if it's
     * correct.
     */
    public String resourceManager(String [] userInput){
        if(inputFormatCheck(userInput)){
            boolean [] issues = resourcesUsageCheck(userInput);
            String result = formattingOutput(issues,userInput[0]);
            System.out.println(result);
            return result;
        }
        return "Input had structural errors.";

    }

    public static void main(String[] args) {
        ClRmSystem rmSystem = new ClRmSystem();
        String [] indElements = rmSystem.parsingInput();
        System.out.println(rmSystem.resourceManager(indElements));

    }

}
