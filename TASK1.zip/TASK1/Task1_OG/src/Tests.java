import org.junit.BeforeClass;
import org.junit.Test;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import static junit.framework.TestCase.*;



public class Tests {

    public static ClRmSystem clRmSystem;
    @BeforeClass
    public static void beforeClass(){
        clRmSystem = new ClRmSystem();
    }

    //Check behaviour given more than 4 arguments.
    @Test
    public void inputFormatTestExtraParam() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","33","434","42","454"};
        Method inputFormatCheck = clRmSystem.getClass().getDeclaredMethod("inputFormatCheck",String[].class);
        inputFormatCheck.setAccessible(true);
        boolean result = (boolean) inputFormatCheck.invoke(clRmSystem,(Object)input);
        assertFalse(result);
    }

    //Check behaviour with unexpected string type.
    @Test
    public void inputFormatTestWrongType() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"string","33","434","42"};
        Method inputFormatCheck = clRmSystem.getClass().getDeclaredMethod("inputFormatCheck",String[].class);
        inputFormatCheck.setAccessible(true);
        boolean result = (boolean) inputFormatCheck.invoke(clRmSystem,(Object)input);
        assertFalse(result);
    }

    //Check behaviour with negative values.
    @Test
    public void inputFormatTestNegativeValues() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"string","-1","434","42"};
        Method inputFormatCheck = clRmSystem.getClass().getDeclaredMethod("inputFormatCheck",String[].class);
        inputFormatCheck.setAccessible(true);
        boolean result = (boolean) inputFormatCheck.invoke(clRmSystem,(Object)input);
        assertFalse(result);
    }

    //Check behaviour with CPU violation.
    @Test
    public void resourceCheckTestCpuViol() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","100","43","42"};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("resourcesUsageCheck",String[].class);
        resourcesCheck.setAccessible(true);
        boolean[] result = (boolean[]) resourcesCheck.invoke(clRmSystem,(Object)input);
        assertTrue(result[1]);
    }

    //Check behaviour with an accepted value for the CPU usage.
    @Test
    public void resourceCheckTestCpuNormalCase() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","20","43","42"};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("resourcesUsageCheck",String[].class);
        resourcesCheck.setAccessible(true);
        boolean[] result = (boolean[]) resourcesCheck.invoke(clRmSystem,(Object)input);
        assertFalse(result[1]);
    }

    //Check behaviour with memory violation.
    @Test
    public void resourceCheckTestMemViolation() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","20","76","42"};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("resourcesUsageCheck",String[].class);
        resourcesCheck.setAccessible(true);
        boolean[] result = (boolean[]) resourcesCheck.invoke(clRmSystem,(Object)input);
        assertTrue(result[2]);
    }

    //Check behaviour with an accepted value for memory usage.
    @Test
    public void resourceCheckTestMemNormalCase() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","20","60","42"};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("resourcesUsageCheck",String[].class);
        resourcesCheck.setAccessible(true);
        boolean[] result = (boolean[]) resourcesCheck.invoke(clRmSystem,(Object)input);
        assertFalse(result[2]);
    }

    //Check behaviour with disk violation
    @Test
    public void resourceCheckTestDiskViolation() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","20","43","61"};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("resourcesUsageCheck",String[].class);
        resourcesCheck.setAccessible(true);
        boolean[] result = (boolean[]) resourcesCheck.invoke(clRmSystem,(Object)input);
        assertTrue(result[3]);
    }

    //Check behaviour with disk violation
    @Test
    public void resourceCheckTestDiskNormalCase() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","20","43","50"};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("resourcesUsageCheck",String[].class);
        resourcesCheck.setAccessible(true);
        boolean[] result = (boolean[]) resourcesCheck.invoke(clRmSystem,(Object)input);
        assertFalse(result[3]);
    }

    //Test behaviour with all resources being overused.
    @Test
    public void resourceCheckTestAllResourcesOverused() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String [] input = {"1234","20","79","55"};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("resourcesUsageCheck",String[].class);
        resourcesCheck.setAccessible(true);
        boolean[] result = (boolean[]) resourcesCheck.invoke(clRmSystem,(Object)input);
        assertFalse(result[3]);
    }

    //Check the output given no violations.
    @Test
    public void formattingOutputTestNoViolations() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String expected = "(No Alert,1234)";
        boolean [] issues = {false,false,false,false};
        String serverID = "1234";
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("formattingOutput",boolean[].class, String.class);
        resourcesCheck.setAccessible(true);
        String result = (String) resourcesCheck.invoke(clRmSystem,issues,(Object) serverID);
        assertEquals(expected,result);

    }

    //Test the output with CPU violation.
    @Test
    public void formattingOutputTestCpuViol() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String expected = "(Alert,1234,CPU_UTILIZATION VIOLATED)";
        String serverID = "1234";
        boolean [] issues = {true,true,false,false};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("formattingOutput",boolean[].class, String.class);
        resourcesCheck.setAccessible(true);
        String result = (String) resourcesCheck.invoke(clRmSystem,issues,(Object) serverID);
        System.out.println(result);
        assertEquals(expected,result);
    }

    //Test the output with Memory violation.
    @Test
    public void formattingOutputTestMemViol() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String expected = "(Alert,1234,MEMORY_UTILIZATION VIOLATED)";
        String serverID = "1234";
        boolean [] issues = {true,false,true,false};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("formattingOutput",boolean[].class, String.class);
        resourcesCheck.setAccessible(true);
        String result = (String) resourcesCheck.invoke(clRmSystem,issues,(Object) serverID);
        System.out.println(result);
        assertEquals(expected,result);
    }

    //Test the output with disk violation.
    @Test
    public void formattingOutputTestDiskViol() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String expected = "(Alert,1234,DISK_UTILIZATION VIOLATED)";
        String serverID = "1234";
        boolean [] issues = {true,false,false,true};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("formattingOutput",boolean[].class, String.class);
        resourcesCheck.setAccessible(true);
        String result = (String) resourcesCheck.invoke(clRmSystem,issues,(Object) serverID);
        System.out.println(result);
        assertEquals(expected,result);
    }

    // Test the output with all violations.
    @Test
    public void formattingOutputTestAllResViol() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String expected = "(Alert,1234,CPU_UTILIZATION VIOLATED,MEMORY_UTILIZATION VIOLATED,DISK_UTILIZATION VIOLATED)";
        String serverID = "1234";
        boolean [] issues = {true,true,true,true};
        Method resourcesCheck = clRmSystem.getClass().getDeclaredMethod("formattingOutput",boolean[].class, String.class);
        resourcesCheck.setAccessible(true);
        String result = (String) resourcesCheck.invoke(clRmSystem,issues,(Object) serverID);
        System.out.println(result);
        assertEquals(expected,result);
    }

    //Test if output is correct with no violations
    @Test
    public void resourceManageTestNoAlert(){
        String expected = "(No Alert,1234)";
        String [] indElements = {"1234","50","50","50"};
        String outptut = clRmSystem.resourceManager(indElements);
        assertEquals(expected,outptut);
    }

    //Test if output is correct with incorrect format(3 args).
    @Test
    public void resourceManageTestWithAlert(){
        String [] indElements = {"1234","100","100"};
        String output = clRmSystem.resourceManager(indElements);
        assertEquals("Input had structural errors.",output);
    }

    //Test if output is correct with wrong types in input.
    @Test
    public void resourceManageTestTypeError(){
        String [] indElements = {"1adsjf34","100","100","3"};
        String output = clRmSystem.resourceManager(indElements);
        assertEquals("Input had structural errors.",output);
    }

    //Test if output is correct with negative value in input.
    @Test
    public void resourceManageTestNegativeValue(){
        String [] indElements = {"1334","-1","100","39"};
        String output = clRmSystem.resourceManager(indElements);
        assertEquals("Input had structural errors.",output);
    }
}
